# Stock Signals Radar - Personal Stock Analysis Dashboard

A real-time stock analysis dashboard that provides buy/sell signals based on technical indicators (RSI, SMA) and analyst recommendations.

## Features

- Real-time stock prices from Yahoo Finance API
- Technical analysis with RSI and SMA indicators
- Analyst target prices and recommendations
- Price range filter to search through 50 stocks
- Bilingual support (English/Arabic)
- Telegram alerts for price targets
- Persistent pinned stocks
- Interactive charts with forecast predictions

## Project Structure

```
stock-signals-radar/
├── backend/           # FastAPI backend
│   ├── app/
│   │   └── main.py   # Main API server
│   └── pyproject.toml # Python dependencies
├── frontend/          # React + Vite frontend
│   ├── src/
│   │   ├── App.tsx   # Main application
│   │   └── components/
│   └── package.json  # Node dependencies
```

## Requirements

### Backend
- Python 3.10 or higher
- Poetry (Python package manager)

### Frontend
- Node.js 18 or higher
- npm or yarn

## Installation on Windows

### Step 1: Install Python

1. Download Python from https://www.python.org/downloads/
2. During installation, check "Add Python to PATH"
3. Verify installation: Open Command Prompt and run:
   ```
   python --version
   ```

### Step 2: Install Poetry (Python Package Manager)

Open PowerShell as Administrator and run:
```powershell
(Invoke-WebRequest -Uri https://install.python-poetry.org -UseBasicParsing).Content | python -
```

Add Poetry to PATH:
- Add `%APPDATA%\Python\Scripts` to your system PATH

Verify installation:
```
poetry --version
```

### Step 3: Install Node.js

1. Download Node.js LTS from https://nodejs.org/
2. Run the installer
3. Verify installation:
   ```
   node --version
   npm --version
   ```

### Step 4: Setup Backend

Open Command Prompt and navigate to the backend folder:
```cmd
cd path\to\stock-signals-radar\backend
```

Install dependencies:
```cmd
poetry install
```

Create a `.env` file in the backend folder (optional, for Telegram alerts):
```
TELEGRAM_BOT_TOKEN=your_bot_token
TELEGRAM_CHAT_ID=your_chat_id
```

Start the backend server:
```cmd
poetry run fastapi dev app/main.py
```

The backend will run at: http://localhost:8000

### Step 5: Setup Frontend

Open a new Command Prompt and navigate to the frontend folder:
```cmd
cd path\to\stock-signals-radar\frontend
```

Install dependencies:
```cmd
npm install
```

Create a `.env` file in the frontend folder:
```
VITE_API_URL=http://localhost:8000
```

Start the frontend development server:
```cmd
npm run dev
```

The frontend will run at: http://localhost:5173

## Running the Application

1. Start the backend first (in one terminal):
   ```cmd
   cd backend
   poetry run fastapi dev app/main.py
   ```

2. Start the frontend (in another terminal):
   ```cmd
   cd frontend
   npm run dev
   ```

3. Open your browser and go to: http://localhost:5173

## Building for Production

### Backend
The backend is ready for deployment on platforms like Fly.io, Railway, or Render.

### Frontend
Build the production version:
```cmd
cd frontend
npm run build
```

The built files will be in the `frontend/dist` folder.

## API Endpoints

- `GET /api/stocks` - Get stock recommendations
- `GET /api/stocks?min_price=50&max_price=150` - Filter by price range
- `GET /api/stocks?sort_by=price` - Sort by price
- `GET /api/search/{symbol}` - Search for a specific stock
- `GET /api/stock/{symbol}` - Get detailed stock information
- `POST /api/telegram/configure` - Configure Telegram alerts
- `POST /api/alerts/set` - Set price alert
- `GET /healthz` - Health check

## Security Notes

- CORS is configured to allow only specific origins
- Stock symbols are validated using regex to prevent injection
- No sensitive data is stored in the frontend

## Troubleshooting

### Backend won't start
- Make sure Python 3.10+ is installed
- Run `poetry install` to install dependencies
- Check if port 8000 is available

### Frontend won't start
- Make sure Node.js 18+ is installed
- Run `npm install` to install dependencies
- Check if port 5173 is available

### No stock data showing
- The backend needs to fetch data from Yahoo Finance
- Wait a few seconds for the initial data load
- Check the backend console for any error messages

## License

This project is for personal use only.
